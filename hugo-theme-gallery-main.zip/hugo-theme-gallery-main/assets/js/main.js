import "./menu.js";
import "./gallery.js";
import "./lightbox.js";
