---
description: A private gallery that is only available by direct link.
private: true # This gallery does not show in lists, RSS, sitemaps, etc. On list pages, use cascade to hide descendants.
title: Private
#type: gallery
---
