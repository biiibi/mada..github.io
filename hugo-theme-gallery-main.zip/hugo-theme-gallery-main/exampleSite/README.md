# Example site for hugo-theme-gallery

## Installation

```
# Install Hugo module
hugo mod get
hugo mod npm pack

# Install NPM dependencies like Tailwind CSS
npm install

# Pull example images from Unsplash
./pull-images.sh
```
